"""
Splits an already-generated HLD/LLD markdown file into one file per top-level
section, so a huge end-to-end design doc doesn't have to be attached in full
every time - only the section(s) actually relevant to the current task do.

Purely structural (splits on heading boundaries in the already-correct
markdown) - no model, fully deterministic, and the split is validated to
reproduce the original EXACTLY (byte for byte) when all section files are
concatenated back together in order, so splitting can never silently drop
content the way a model-based summarizer/chunker could.
"""

import re
from pathlib import Path

from .optimize import estimate_tokens

HEADING_RE = re.compile(r"^(#{1,6})\s+(.*)$")


def _slugify(text: str, max_len: int = 40) -> str:
    text = re.sub(r"[^\w\s-]", "", text).strip()
    text = re.sub(r"\s+", "_", text)
    return text[:max_len].rstrip("_") or "section"


def split_by_headings(markdown_text: str, split_level: int = 2):
    """
    Splits markdown_text into sections at headings whose level is <= split_level
    (e.g. split_level=2 splits at both '#' and '##', keeping '###'+ nested inside
    their parent section). Content before the first qualifying heading becomes
    a "Preamble" section if non-empty.

    Returns a list of {"title": str, "level": int, "content": str} in original
    order. CRITICAL INVARIANT, relied on by validation: "\\n".join(s["content"]
    for s in sections) reproduces markdown_text EXACTLY - every line from the
    input is placed into exactly one section, none dropped or duplicated.
    """
    lines = markdown_text.split("\n")
    sections = []
    current_title = "Preamble"
    current_level = 0
    current_lines = []

    def flush():
        if current_lines and any(l.strip() for l in current_lines):
            sections.append({"title": current_title, "level": current_level, "content": "\n".join(current_lines)})

    for line in lines:
        m = HEADING_RE.match(line)
        if m and len(m.group(1)) <= split_level:
            flush()
            current_title = m.group(2).strip()
            current_level = len(m.group(1))
            current_lines = [line]
        else:
            current_lines.append(line)
    flush()

    if not sections:  # no qualifying headings at all - whole doc is one section
        sections = [{"title": "Full Document", "level": 0, "content": markdown_text}]

    return sections


def write_split_sections(full_text: str, ai_text: str, stem: str, output_dir: Path, split_level: int = 2):
    """
    Writes paired full/ai section files into <output_dir>/<stem>_sections/, plus
    an index.md summarizing every section (title, filenames, approx token cost).

    Returns (section_dir, index_path, ai_sections) - ai_sections is returned so
    the caller can validate the split reconstructs the original exactly.
    """
    section_dir = Path(output_dir) / f"{stem}_sections"
    section_dir.mkdir(parents=True, exist_ok=True)

    full_sections = split_by_headings(full_text, split_level)
    ai_sections = split_by_headings(ai_text, split_level)

    index_lines = [
        f"# Section index — {stem}",
        "",
        "Attach only the section(s) relevant to your current task instead of the whole document.",
        "",
        "| # | Section | Level | Full file (human review) | AI file (use for Copilot) | AI tokens (est.) |",
        "|---|---|---|---|---|---|",
    ]

    for i, sec in enumerate(ai_sections, start=1):
        slug = _slugify(sec["title"])
        full_fname = f"{stem}__{i:02d}_{slug}.md"
        ai_fname = f"{stem}__{i:02d}_{slug}.ai.md"

        (section_dir / ai_fname).write_text(sec["content"].strip() + "\n", encoding="utf-8")

        # full_sections and ai_sections are positionally aligned: headings/order
        # are identical between the two variants (only image handling differs
        # between full/ai mode, never heading text or position).
        full_content = full_sections[i - 1]["content"] if i - 1 < len(full_sections) else ""
        (section_dir / full_fname).write_text(full_content.strip() + "\n", encoding="utf-8")

        tokens = estimate_tokens(sec["content"])
        index_lines.append(
            f"| {i} | {sec['title']} | H{sec['level'] or '-'} | `{full_fname}` | `{ai_fname}` | ~{tokens:,} |"
        )

    index_path = section_dir / "index.md"
    index_path.write_text("\n".join(index_lines) + "\n", encoding="utf-8")

    return section_dir, index_path, ai_sections
