import argparse
import sys
from pathlib import Path

from .converter import convert
from .validate import validate
from .captioning import NullCaptioner, AnthropicVisionCaptioner, OllamaVisionCaptioner


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="docx2md",
        description="Convert HLD/LLD .docx design documents to Markdown with zero data loss, "
        "with a built-in validation step.",
    )
    parser.add_argument("docx_files", nargs="+", help="One or more .docx files to convert")
    parser.add_argument("-o", "--output-dir", default="./output", help="Output directory (default: ./output)")
    parser.add_argument(
        "--caption-images",
        action="store_true",
        help="Run vision captioning on extracted diagrams",
    )
    parser.add_argument(
        "--caption-backend",
        choices=["anthropic", "ollama"],
        default="ollama",
        help="Which vision backend to use for --caption-images. 'ollama' (default) runs fully "
        "locally, no network egress - use this for sensitive docs. 'anthropic' calls the "
        "Anthropic API over the network.",
    )
    parser.add_argument(
        "--caption-model",
        default=None,
        help="Override the default model for the chosen backend, "
        "e.g. --caption-model qwen3-vl:4b or --caption-model llama3.2-vision",
    )
    parser.add_argument(
        "--ollama-host",
        default="http://localhost:11434",
        help="Ollama host URL when --caption-backend=ollama (default: http://localhost:11434)",
    )
    parser.add_argument(
        "--diagram-xml-dir",
        default=None,
        help="Directory of manually-exported draw.io XML files (File -> Export -> XML, "
        "'Compressed' unchecked), matched by filename to extracted images "
        "(assets/image-001.png -> <dir>/image-001.xml). Deterministic, no model - "
        "takes priority over --caption-images for any image with a matching file.",
    )
    parser.add_argument(
        "--split-sections",
        action="store_true",
        help="Also split HLD/LLD into one file per section (plus an index.md), so only the "
        "relevant section(s) need to be attached to Copilot instead of the whole document.",
    )
    parser.add_argument(
        "--split-heading-level",
        type=int,
        default=2,
        choices=[1, 2, 3, 4, 5, 6],
        help="Heading level to split on with --split-sections (default: 2, i.e. splits at "
        "'#' and '##', keeping '###'+ nested inside their section).",
    )
    parser.add_argument(
        "--fail-on-validation-error",
        action="store_true",
        help="Exit with non-zero status if the validation report contains any FAIL",
    )
    args = parser.parse_args(argv)

    captioner = NullCaptioner()
    if args.caption_images:
        if args.caption_backend == "ollama":
            captioner = OllamaVisionCaptioner(
                model=args.caption_model or "qwen3-vl:8b",
                host=args.ollama_host,
            )
        else:
            captioner = AnthropicVisionCaptioner(model=args.caption_model or "claude-sonnet-5")

    overall_ok = True
    for docx_file in args.docx_files:
        docx_path = Path(docx_file)
        if not docx_path.exists():
            print(f"[docx2md] ERROR: file not found: {docx_path}", file=sys.stderr)
            overall_ok = False
            continue

        print(f"[docx2md] Converting {docx_path} ...")
        result = convert(
            docx_path,
            args.output_dir,
            caption_images=args.caption_images,
            captioner=captioner,
            diagram_xml_dir=args.diagram_xml_dir,
            split_sections=args.split_sections,
            split_heading_level=args.split_heading_level,
        )
        print(f"[docx2md]   -> {result.md_path}       (full, human-reviewable)")
        print(f"[docx2md]   -> {result.ai_md_path}    (token-optimized, for Copilot/AI-DLC)")
        if result.num_sections:
            print(f"[docx2md]   -> {result.section_dir}  ({result.num_sections} section files + index.md)")
        if result.drawio_xml_errors:
            for path, err in result.drawio_xml_errors.items():
                print(f"[docx2md]   WARNING: draw.io XML not usable: {err}")

        report = validate(result)
        report_path = Path(args.output_dir) / (docx_path.stem + ".validation.md")
        report_path.write_text(report.to_markdown(docx_path.name), encoding="utf-8")
        print(f"[docx2md]   -> {report_path}  [{'PASS' if report.passed else 'FAIL'}]")
        for n in report.notes:
            print(f"[docx2md]   NOTE: {n}")
        if result.full_tokens_est:
            savings = round((1 - result.ai_tokens_est / result.full_tokens_est) * 100, 1)
            print(
                f"[docx2md]   Token estimate: full≈{result.full_tokens_est:,} "
                f"ai≈{result.ai_tokens_est:,} ({savings}% reduction)"
            )

        if not report.passed:
            overall_ok = False
            for c in report.checks:
                if c["status"] == "FAIL":
                    print(f"[docx2md]   FAIL: {c['name']} — source={c['source']} generated={c['generated']}")

    if args.fail_on_validation_error and not overall_ok:
        sys.exit(1)


if __name__ == "__main__":
    main()
