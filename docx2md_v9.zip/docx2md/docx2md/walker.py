"""
python-docx exposes document.paragraphs and document.tables as two SEPARATE flat lists,
which loses the original interleaving order of the document (e.g. "para, para, table,
para, table, table, para..."). For a design doc, order matters: a table that follows a
specific paragraph needs to stay attached to it. This module walks the raw XML body and
yields Paragraph/Table objects (wrapped python-docx objects) in their true document order.
"""

from docx import Document
from docx.document import Document as _Document
from docx.oxml.ns import qn
from docx.oxml.table import CT_Tbl
from docx.oxml.text.paragraph import CT_P
from docx.table import Table, _Cell
from docx.text.paragraph import Paragraph


def _expand_block(child, parent):
    """
    Yields Paragraph/Table objects for this XML child, transparently expanding
    <w:sdt> (content control / structured document tag) wrappers - which can
    be nested (e.g. a "repeating section" content control wrapping several
    inner content controls, one per repeated instance).

    This matters because content controls are extremely common in enterprise
    Word templates (used for guidance placeholders, structured fields,
    repeating sections) and their content lives inside <w:sdt><w:sdtContent>,
    one level deeper than a direct child of the body/cell - so a plain
    child-only walk (and even python-docx's own .paragraphs property) misses
    it ENTIRELY. Confirmed empirically: a paragraph wrapped in a content
    control does not appear in document.paragraphs at all.
    """
    if isinstance(child, CT_P):
        yield Paragraph(child, parent)
    elif isinstance(child, CT_Tbl):
        yield Table(child, parent)
    elif child.tag == qn("w:sdt"):
        sdt_content = child.find(qn("w:sdtContent"))
        if sdt_content is not None:
            for sub_child in sdt_content.iterchildren():
                yield from _expand_block(sub_child, parent)


def iter_block_items(parent):
    """
    Yield each paragraph and table child (in document order) of `parent`,
    which can be a Document, or a _Cell (for nested content in table cells).
    Transparently expands content-control (<w:sdt>) wrappers - see _expand_block.
    """
    if isinstance(parent, _Document):
        parent_elm = parent.element.body
    elif isinstance(parent, _Cell):
        parent_elm = parent._tc
    else:
        raise ValueError("iter_block_items: unsupported parent type %r" % type(parent))

    for child in parent_elm.iterchildren():
        yield from _expand_block(child, parent)


def iter_all_paragraphs(parent):
    """
    Recursively yields every Paragraph in the document, including those nested
    inside table cells (and cells nested inside cells). Used for word-count /
    completeness validation, where we need the true total, not just the
    top-level flat list python-docx's document.paragraphs gives you.
    """
    for block in iter_block_items(parent):
        if isinstance(block, Paragraph):
            yield block
        elif isinstance(block, Table):
            for row in block.rows:
                for cell in row.cells:
                    yield from iter_all_paragraphs(cell)


def iter_all_tables(parent):
    """Recursively yields every Table, including tables nested inside table cells."""
    for block in iter_block_items(parent):
        if isinstance(block, Table):
            yield block
            for row in block.rows:
                for cell in row.cells:
                    yield from iter_all_tables(cell)


def walk_document(docx_path):
    """
    Returns (document, list_of_block_items) where block items are Paragraph/Table
    objects in true document order.
    """
    document = Document(docx_path)
    blocks = list(iter_block_items(document))
    return document, blocks
