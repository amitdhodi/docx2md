"""
When source vs generated word count doesn't converge, this scans the raw
document XML for structural patterns known to be traps for tools built on
python-docx - reporting COUNTS ONLY, never actual document text/content, so
this is safe to share even for sensitive documents. Each category notes
whether this utility currently handles it, so a persistent gap after fixes
points precisely at what's still unhandled rather than requiring guesswork.
"""

from docx.oxml.ns import qn


def _count(root, tag):
    return len(root.findall(".//" + qn(tag)))


def _text_word_count(elements):
    total = 0
    for el in elements:
        text = "".join(t.text or "" for t in el.findall(".//" + qn("w:t")))
        total += len(text.split())
    return total


def diagnose(document):
    """
    Returns a list of {"label", "count", "approx_words", "handled", "note"}
    dicts, one per structural category checked, ordered roughly by how likely
    each is to explain a word-count gap.
    """
    body = document.element.body
    findings = []

    ins_elements = body.findall(".//" + qn("w:ins"))
    findings.append({
        "label": "Tracked-change insertions (w:ins, not yet accepted)",
        "count": len(ins_elements),
        "approx_words": _text_word_count(ins_elements),
        "handled": True,
        "note": "Now extracted correctly as normal content.",
    })

    del_elements = body.findall(".//" + qn("w:del"))
    del_words = 0
    for el in del_elements:
        text = "".join(t.text or "" for t in el.findall(".//" + qn("w:delText")))
        del_words += len(text.split())
    findings.append({
        "label": "Tracked-change deletions (w:del, not yet accepted)",
        "count": len(del_elements),
        "approx_words": del_words,
        "handled": True,
        "note": "Intentionally excluded from both source and generated counts "
                "(reviewer-marked-for-removal text isn't final content).",
    })

    sdt_elements = body.findall(".//" + qn("w:sdt"))
    findings.append({
        "label": "Content controls / structured document tags (w:sdt)",
        "count": len(sdt_elements),
        "approx_words": _text_word_count(sdt_elements),
        "handled": True,
        "note": "Now extracted correctly - previously INVISIBLE to both this "
                "tool and python-docx's own .paragraphs property entirely.",
    })

    # Text boxes: DrawingML (wps:txbx) and legacy VML (v:textbox) both wrap
    # their text in w:txbxContent, which is nested inside shape/drawing XML
    # this tool does not currently walk at all.
    txbx_elements = body.findall(".//" + qn("w:txbxContent"))
    findings.append({
        "label": "Text boxes (w:txbxContent)",
        "count": len(txbx_elements),
        "approx_words": _text_word_count(txbx_elements),
        "handled": False,
        "note": "NOT currently extracted - text inside text boxes/callouts is "
                "invisible to this tool's output. Likely explanation if a gap "
                "remains after re-running with this update.",
    })

    fld_simple = body.findall(".//" + qn("w:fldSimple"))
    fld_char_begin = [
        f for f in body.findall(".//" + qn("w:fldChar"))
        if f.get(qn("w:fldCharType")) == "begin"
    ]
    findings.append({
        "label": "Fields (w:fldSimple + complex field codes)",
        "count": len(fld_simple) + len(fld_char_begin),
        "approx_words": _text_word_count(fld_simple),  # complex field result text is harder to isolate reliably
        "handled": False,
        "note": "Simple fields (e.g. cross-references, TOC entries) may not "
                "be fully captured; complex field result text (begin/separate/"
                "end sequences) is not reliably extracted at all.",
    })

    footnote_refs = _count(body, "w:footnoteReference")
    endnote_refs = _count(body, "w:endnoteReference")
    findings.append({
        "label": "Footnote / endnote references",
        "count": footnote_refs + endnote_refs,
        "approx_words": None,
        "handled": False,
        "note": "Reference markers found in the body, but footnote/endnote BODY "
                "text lives in separate document parts (footnotes.xml/endnotes.xml) "
                "this tool does not currently read at all.",
    })

    comment_refs = _count(body, "w:commentReference")
    findings.append({
        "label": "Comment references",
        "count": comment_refs,
        "approx_words": None,
        "handled": False,
        "note": "Comment bubble text lives in a separate document part "
                "(comments.xml) this tool does not read. Comments are "
                "reviewer notes, not final content, so this is likely fine to "
                "leave unhandled - flagged for visibility only.",
    })

    return findings


def diagnose_to_markdown(document) -> str:
    findings = diagnose(document)
    lines = [
        "# Word-count gap diagnostic",
        "",
        "Structural element counts only - no document text is included below.",
        "",
        "| Structure | Count | Approx. words | Handled by this tool? | Note |",
        "|---|---|---|---|---|",
    ]
    for f in findings:
        words = f["approx_words"] if f["approx_words"] is not None else "-"
        handled = "Yes" if f["handled"] else "**NO**"
        lines.append(f"| {f['label']} | {f['count']} | {words} | {handled} | {f['note']} |")
    return "\n".join(lines)
