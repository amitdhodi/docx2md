# docx2md — Lossless HLD/LLD DOCX → Markdown Converter

Converts HLD/LLD design docs from `.docx` to `.md` for use as AI-agent input
(e.g. AWS AI-DLC Construction phase), with a built-in validation step so a
lossy conversion never silently becomes the agent's source of truth.

## Why this exists

Design docs feeding an AI coding agent are only as good as the fidelity of
the conversion. Generic DOCX→Markdown tools tend to silently drop:
- merged table cells (Markdown tables have no colspan/rowspan concept)
- list numbering/nesting (many tools flatten to plain paragraphs)
- diagrams (become an unreadable image link with no semantic content for a
  text-only agent, or get dropped outright if they're vector/SmartArt shapes)

This utility handles each of those explicitly and **validates** that nothing
was lost, rather than assuming success.

## Install

```bash
pip install -r requirements.txt
# Optional, for --caption-images:
pip install anthropic
# Optional, for Tier-2 diagram fallback rendering (SmartArt/vector shapes):
sudo apt-get install libreoffice   # or: brew install --cask libreoffice
```

## Usage

```bash
python -m docx2md HLD.docx LLD.docx -o ./ai-design-package

# With diagram captioning (requires ANTHROPIC_API_KEY):
python -m docx2md HLD.docx --caption-images -o ./ai-design-package

# Treat any validation FAIL as a hard error (e.g. in CI):
python -m docx2md HLD.docx --fail-on-validation-error -o ./ai-design-package
```

Output layout:

```
ai-design-package/
├── HLD.md
├── HLD.validation.md          <- read this before trusting HLD.md
├── LLD.md
├── LLD.validation.md
└── assets/
    ├── image-001.png          <- natively extracted diagrams (Tier 1)
    └── full_document_page_renders/   <- only created if Tier-2 fallback triggered
        └── page-001.png
```

## How fidelity is preserved

| Source content | Handling |
|---|---|
| Headings | Style-based detection (`Heading 1`..`6`, `Title`) → `#`..`######` |
| Bold/italic | Preserved via run formatting → `**bold**` / `*italic*` |
| Bulleted/numbered lists | Read from `numbering.xml` (with a style-name fallback for docs that use named list styles without explicit `numPr`); nesting preserved via indent |
| Tables, no merges | Clean Markdown table |
| Tables, with merged cells | Rendered as inline HTML `<table>` with real `rowspan`/`colspan` — Markdown tables cannot represent merges, so flattening them would be silent data loss |
| Diagrams (raster) | Extracted directly from the docx package at original resolution into `assets/` |
| Diagrams (EMF/WMF vector) | Converted to PNG via LibreOffice headless |
| Diagrams (SmartArt / pure vector shapes with no raster fallback) | Tier-2 fallback: whole document rendered to page images in `assets/full_document_page_renders/`, and explicitly flagged in the validation report for manual review — never silently dropped |
| Diagram *semantics* (optional) | `--caption-images` runs each extracted diagram through a vision model and appends a text description under the image, so a text-only AI agent still gets the diagram's content |

## Validation step

Every conversion produces a `<name>.validation.md` report that independently
recomputes counts from the **source** `.docx` (headings, tables, unique
table cells post-merge, word count, images) and compares them against the
**generated** `.md`. Exact-match categories must match exactly; word count
allows a small tolerance (Markdown syntax characters shift word-splitting
slightly). Any mismatch fails the report and is printed to the console,
so a silently-lossy conversion never reaches the AI agent as a false
"complete" input.

## Known limitations (by design, always surfaced in the report, never silent)

- Tables nested inside other table cells are extracted (recursively), but
  deeply nested layout tables used purely for visual formatting are treated
  the same as content tables.
- SmartArt/pure-vector diagrams without a raster fallback require LibreOffice
  to be installed for the Tier-2 fallback; without it, the report explicitly
  says so and fails validation rather than pretending nothing was lost.
- `--caption-images` requires network access and API credentials; it's opt-in
  and never silently skipped without a note in the report.
