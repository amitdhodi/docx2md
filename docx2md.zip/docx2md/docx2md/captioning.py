"""
Optional step: describe each extracted diagram in text so a text-only AI agent
(one that doesn't see the referenced image) still gets the diagram's semantic
content. This is intentionally pluggable - wire up whatever vision model your
org standardizes on (Bedrock, Anthropic API, Azure OpenAI, etc).

Left as an explicit opt-in (--caption-images) rather than default-on, since it
requires network/API credentials this utility shouldn't assume are present.
"""

import base64
from abc import ABC, abstractmethod
from pathlib import Path


class Captioner(ABC):
    @abstractmethod
    def caption(self, image_path: Path) -> str:
        """Return a text description of the diagram at image_path."""
        raise NotImplementedError


class NullCaptioner(Captioner):
    """Default no-op: leaves images as image-only references. Use when no
    vision API is configured; the validation report will note captioning was skipped."""

    def caption(self, image_path: Path) -> str:
        return ""


class AnthropicVisionCaptioner(Captioner):
    """
    Example implementation using the Anthropic API. Requires:
        pip install anthropic
        export ANTHROPIC_API_KEY=...
    """

    PROMPT = (
        "This image is a diagram from a software High-Level or Low-Level Design "
        "document. Describe it precisely and completely for an engineer who cannot "
        "see the image: components/boxes present, the relationships/arrows between "
        "them (direction and label if any), any numbered sequence of calls, and any "
        "text labels. Be literal and complete, not interpretive. Output plain text, "
        "no markdown headers."
    )

    def __init__(self, model: str = "claude-sonnet-5"):
        import anthropic  # imported lazily so it's not a hard dependency

        self._client = anthropic.Anthropic()
        self._model = model

    def caption(self, image_path: Path) -> str:
        ext = image_path.suffix.lower().lstrip(".")
        media_type = f"image/{'jpeg' if ext == 'jpg' else ext}"
        data = base64.standard_b64encode(image_path.read_bytes()).decode("utf-8")

        response = self._client.messages.create(
            model=self._model,
            max_tokens=600,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "image", "source": {"type": "base64", "media_type": media_type, "data": data}},
                        {"type": "text", "text": self.PROMPT},
                    ],
                }
            ],
        )
        return "".join(block.text for block in response.content if block.type == "text").strip()


def caption_all(image_map: dict, captioner: Captioner) -> dict:
    """
    Mutates image_map in place: appends a '> **Diagram description:** ...' blockquote
    to each image's markdown snippet. Returns the same image_map for chaining.
    """
    for entry in image_map.values():
        if entry["kind"] != "raster":
            continue  # don't caption unresolved vector/emf assets - flagged separately
        try:
            description = captioner.caption(entry["path"])
        except Exception as exc:  # never let a captioning failure break the conversion
            description = ""
            entry["caption_error"] = str(exc)
        if description:
            entry["markdown"] = entry["markdown"] + f"\n\n> **Diagram description:** {description}"
    return image_map
