import re
from dataclasses import dataclass, field
from pathlib import Path

from docx.table import Table
from docx.text.paragraph import Paragraph

from .walker import walk_document
from .text import NumberingResolver, paragraph_to_markdown
from .tables import table_to_markdown
from .images import extract_raster_images, count_unresolved_vector_drawings, render_full_document_fallback
from .captioning import Captioner, NullCaptioner, caption_all

LIST_ITEM_RE = re.compile(r"^\d+\.\s")


@dataclass
class ConversionResult:
    docx_path: Path
    md_path: Path
    output_dir: Path
    document: object
    blocks: list
    image_map: dict
    unresolved_vector_drawings: int
    fallback_pages: list = field(default_factory=list)


def _join_blocks(lines):
    """Join rendered block strings with blank-line separation, except adjacent
    list items which stay on consecutive lines (so lists don't render as a
    sequence of separate loose paragraphs)."""
    out = []
    prev_is_list = False
    for line in lines:
        if line == "":
            continue
        stripped = line.lstrip(" ")
        is_list = stripped.startswith("- ") or bool(LIST_ITEM_RE.match(stripped))
        if out:
            out.append("\n" if (is_list and prev_is_list) else "\n\n")
        out.append(line)
        prev_is_list = is_list
    return "".join(out)


def convert(
    docx_path,
    output_dir,
    caption_images: bool = False,
    captioner: Captioner | None = None,
) -> ConversionResult:
    docx_path = Path(docx_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    assets_dir = output_dir / "assets"

    document, blocks = walk_document(docx_path)

    # --- Images (Tier 1: native raster extraction) ---
    image_map = extract_raster_images(document, assets_dir)

    # --- Images (Tier 2: fallback for undetectable vector/SmartArt drawings) ---
    unresolved_vector_count = count_unresolved_vector_drawings(document)
    fallback_pages = []
    if unresolved_vector_count > 0:
        fallback_pages = render_full_document_fallback(docx_path, assets_dir)

    # --- Optional diagram captioning ---
    if caption_images:
        caption_all(image_map, captioner or NullCaptioner())

    # --- Text/table conversion in original document order ---
    numbering_resolver = NumberingResolver(document)
    md_blocks = []
    for block in blocks:
        if isinstance(block, Paragraph):
            md_blocks.append(paragraph_to_markdown(block, numbering_resolver, image_map))
        elif isinstance(block, Table):
            md_blocks.append(table_to_markdown(block, numbering_resolver, image_map, paragraph_to_markdown))

    markdown_text = _join_blocks(md_blocks) + "\n"

    md_path = output_dir / (docx_path.stem + ".md")
    md_path.write_text(markdown_text, encoding="utf-8")

    return ConversionResult(
        docx_path=docx_path,
        md_path=md_path,
        output_dir=output_dir,
        document=document,
        blocks=blocks,
        image_map=image_map,
        unresolved_vector_drawings=unresolved_vector_count,
        fallback_pages=fallback_pages,
    )
