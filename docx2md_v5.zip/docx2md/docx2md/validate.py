"""
The "no data loss" requirement is only real if it's checked, not just claimed.
This module independently re-derives structural counts from the SOURCE .docx
(headings, tables, table cells, images, word count) and compares them against
the same counts derived from the GENERATED markdown. Any exact-match category
that diverges, or any fuzzy-match category (word count) that diverges beyond
tolerance, fails validation loudly rather than letting a silently-lossy
conversion become an AI agent's source of truth.
"""

import re
from dataclasses import dataclass, field
from pathlib import Path

from .walker import iter_all_paragraphs, iter_all_tables

WORD_TOLERANCE_PCT = 5  # word count is approximate (markdown syntax chars shift splits)

MD_HEADING_RE = re.compile(r"^#{1,6}\s", re.MULTILINE)
MD_IMAGE_RE = re.compile(r"!\[")
MD_PIPE_TABLE_ROW_RE = re.compile(r"^\|.+\|\s*$", re.MULTILINE)
HTML_TABLE_RE = re.compile(r"<table>", re.IGNORECASE)
HTML_TABLE_CELL_RE = re.compile(r"<t[dh][ >]", re.IGNORECASE)


@dataclass
class ValidationReport:
    checks: list = field(default_factory=list)  # list of dicts: name, source, generated, status
    passed: bool = True
    notes: list = field(default_factory=list)

    def add(self, name, source_val, generated_val, exact=True, tolerance_pct=0):
        if exact:
            ok = source_val == generated_val
        else:
            if source_val == 0:
                ok = generated_val == 0
            else:
                diff_pct = abs(source_val - generated_val) / source_val * 100
                ok = diff_pct <= tolerance_pct
        self.checks.append(
            {
                "name": name,
                "source": source_val,
                "generated": generated_val,
                "status": "PASS" if ok else "FAIL",
            }
        )
        if not ok:
            self.passed = False

    def to_markdown(self, docx_name):
        lines = [f"# Conversion Validation Report — {docx_name}", ""]
        lines.append("| Check | Source (.docx) | Generated (.md) | Status |")
        lines.append("|---|---|---|---|")
        for c in self.checks:
            lines.append(f"| {c['name']} | {c['source']} | {c['generated']} | {c['status']} |")
        lines.append("")
        lines.append(f"**Overall: {'PASS' if self.passed else 'FAIL — review before using as AI input'}**")
        if self.notes:
            lines.append("")
            lines.append("## Notes / manual-review items")
            for n in self.notes:
                lines.append(f"- {n}")
        return "\n".join(lines)


def _source_counts(document):
    heading_count = 0
    word_count = 0
    for p in iter_all_paragraphs(document):
        style_name = (p.style.name or "") if p.style else ""
        if style_name == "Title" or style_name.startswith("Heading"):
            heading_count += 1
        text = "".join(r.text for r in p.runs)
        word_count += len(text.split())

    tables = list(iter_all_tables(document))
    table_count = len(tables)

    cell_count = 0
    for t in tables:
        # IMPORTANT: collect all tc elements into a list FIRST so they stay alive
        # (strongly referenced) for the whole dedup pass below. python-docx/lxml
        # element proxies are short-lived otherwise, and CPython can reuse the same
        # id() for a *different* cell once the previous one is garbage-collected -
        # silently corrupting the merge-detection count. Keeping `all_tcs` alive
        # for the duration of the loop is what makes id()-based identity safe here.
        all_tcs = [cell._tc for row in t.rows for cell in row.cells]
        seen = set()
        for tc in all_tcs:
            key = id(tc)
            if key not in seen:
                seen.add(key)
                cell_count += 1

    return {
        "heading_count": heading_count,
        "word_count": word_count,
        "table_count": table_count,
        "cell_count": cell_count,
    }


CAPTION_BLOCKQUOTE_RE = re.compile(r"^> \*\*Diagram description[^*]*\*\*.*$", re.MULTILINE)


def _generated_counts(markdown_text):
    heading_count = len(MD_HEADING_RE.findall(markdown_text))

    pipe_tables = _count_pipe_tables(markdown_text)
    html_tables = len(HTML_TABLE_RE.findall(markdown_text))
    table_count = pipe_tables + html_tables

    pipe_cells = _count_pipe_table_cells(markdown_text)
    html_cells = len(HTML_TABLE_CELL_RE.findall(markdown_text))
    cell_count = pipe_cells + html_cells

    # Word count should reflect fidelity to the SOURCE content only. Vision-model
    # diagram descriptions are legitimate additive enrichment (they don't exist
    # in the .docx at all), so they're excluded here - otherwise captioning would
    # trip a false "word count mismatch" on every document that has diagrams.
    word_count_basis = CAPTION_BLOCKQUOTE_RE.sub("", markdown_text)
    stripped = re.sub(r"<[^>]+>", " ", word_count_basis)
    stripped = re.sub(r"!\[.*?\]\(.*?\)", " ", stripped)
    stripped = re.sub(r"[#*|>-]", " ", stripped)
    word_count = len(stripped.split())

    image_count = len(MD_IMAGE_RE.findall(markdown_text))

    return {
        "heading_count": heading_count,
        "word_count": word_count,
        "table_count": table_count,
        "cell_count": cell_count,
        "image_count": image_count,
    }


def _count_pipe_tables(markdown_text):
    """A markdown pipe-table is a block of consecutive '|...|' lines; count blocks, not rows."""
    lines = markdown_text.splitlines()
    count = 0
    in_table = False
    for line in lines:
        is_row = bool(re.match(r"^\|.+\|\s*$", line))
        if is_row and not in_table:
            count += 1
            in_table = True
        elif not is_row:
            in_table = False
    return count


def _is_separator_row(line):
    """Matches a GFM header-separator row like '| --- | --- | --- |', regardless
    of column count (the naive single-column regex used previously failed on
    anything with more than one column, since '|' isn't in its character class)."""
    stripped = line.strip()
    if not stripped.startswith("|") or not stripped.endswith("|"):
        return False
    inner = stripped.strip("|")
    return bool(inner) and "-" in inner and all(c in " :-|" for c in inner)


def _count_pipe_table_cells(markdown_text):
    """Counts data cells in pipe tables (excludes the '---' separator row)."""
    lines = markdown_text.splitlines()
    total = 0
    for line in lines:
        if _is_separator_row(line):
            continue  # separator row, e.g. | --- | --- | --- |
        if re.match(r"^\|.+\|\s*$", line):
            cells = [c for c in line.strip().strip("|").split("|")]
            total += len(cells)
    return total


AI_DIAGRAM_TAG_RE = re.compile(r"\[(?:Diagram|icon)")


def validate(conversion_result) -> ValidationReport:
    report = ValidationReport()
    src = _source_counts(conversion_result.document)
    md_text = Path(conversion_result.md_path).read_text(encoding="utf-8")
    gen = _generated_counts(md_text)

    report.add("Headings", src["heading_count"], gen["heading_count"], exact=True)
    report.add("Tables", src["table_count"], gen["table_count"], exact=True)
    report.add("Table cells (unique, post-merge)", src["cell_count"], gen["cell_count"], exact=True)
    report.add("Word count", src["word_count"], gen["word_count"], exact=False, tolerance_pct=WORD_TOLERANCE_PCT)

    raster_extracted = sum(1 for v in conversion_result.image_map.values() if v["kind"] == "raster")
    expected_refs = getattr(conversion_result, "expected_inline_image_refs", raster_extracted)
    report.add("Images referenced in .md", expected_refs, gen["image_count"], exact=True)

    unconverted_vector = [
        v for v in conversion_result.image_map.values() if v["kind"] == "vector-unconverted"
    ]
    if unconverted_vector:
        exts = sorted({Path(v["path"]).suffix.lower() or "(no extension)" for v in unconverted_vector})
        report.notes.append(
            f"{len(unconverted_vector)} embedded image(s) with extension(s) {', '.join(exts)} could not be "
            f"converted to PNG (LibreOffice unavailable, or the format isn't a LibreOffice-convertible "
            f"vector type) — kept in assets/ in original format; verify these render correctly wherever "
            f"the .md is consumed."
        )

    decorative_icons = [v for v in conversion_result.image_map.values() if v["kind"] == "decorative-icon"]
    if decorative_icons:
        sizes = ", ".join(f"{v['path'].name} ({v['dimensions'][0]}x{v['dimensions'][1]}px)" for v in decorative_icons)
        report.notes.append(
            f"{len(decorative_icons)} small image(s) (<=48px) detected and treated as decorative icons, "
            f"not diagrams: {sizes}. These are commonly panel/macro icons (e.g. Confluence info/note/warning "
            f"panel icons rendered inline next to placeholder text) rather than architecture diagrams, so "
            f"they are NOT flagged for draw.io XML export. If you see the SAME small image reference "
            f"repeated across unrelated sections of the .md (e.g. next to \"TBC\"/\"Guidance\" placeholder "
            f"text), this is very likely why: check assets/ for that filename to confirm what it actually "
            f"shows. If any of these is misclassified (a genuinely small diagram), let us know."
        )

    if conversion_result.unresolved_vector_drawings > 0:
        report.notes.append(
            f"{conversion_result.unresolved_vector_drawings} drawing object(s) (likely SmartArt or "
            f"native vector shapes with no embedded raster fallback) could not be natively extracted. "
            f"A full-page rasterization of the source document was generated at "
            f"assets/full_document_page_renders/ for manual cross-reference — confirm these pages "
            f"don't contain diagram content missing from the .md before using it as AI input."
        )
        if not conversion_result.fallback_pages:
            report.notes.append(
                "Fallback page rendering also failed (LibreOffice/PyMuPDF unavailable) — these "
                "drawings are NOT represented anywhere in the output. Manual review is required."
            )
            report.passed = False

    caption_errors = [
        (v.get("caption_error")) for v in conversion_result.image_map.values() if v.get("caption_error")
    ]
    if caption_errors:
        report.notes.append(f"{len(caption_errors)} diagram(s) failed vision/XML captioning: {caption_errors[0]!r} (etc.)")

    # --- AI-variant integrity check: token optimization must not drop information ---
    if getattr(conversion_result, "ai_md_path", None) and Path(conversion_result.ai_md_path).exists():
        ai_text = Path(conversion_result.ai_md_path).read_text(encoding="utf-8")
        ai_gen = _generated_counts(ai_text)

        report.add("AI variant: headings", gen["heading_count"], ai_gen["heading_count"], exact=True)
        report.add("AI variant: tables", gen["table_count"], ai_gen["table_count"], exact=True)

        ai_diagram_mentions = len(AI_DIAGRAM_TAG_RE.findall(ai_text))
        report.add("AI variant: diagram mentions", expected_refs, ai_diagram_mentions, exact=True)

        full_tok = getattr(conversion_result, "full_tokens_est", 0)
        ai_tok = getattr(conversion_result, "ai_tokens_est", 0)
        if full_tok:
            savings_pct = round((1 - ai_tok / full_tok) * 100, 1)
            report.notes.append(
                f"Token estimate: full .md ≈ {full_tok:,} tokens, .ai.md ≈ {ai_tok:,} tokens "
                f"(~{savings_pct}% reduction). Estimate only (~4 chars/token heuristic)."
            )

    # --- Diagrams still without a description: tell the user exactly what to export ---
    pending = [
        v["expected_xml_name"]
        for v in conversion_result.image_map.values()
        if v["kind"] == "raster" and "no description yet" in v.get("ai_markdown", "")
    ]
    if pending:
        report.notes.append(
            f"{len(pending)} diagram(s) have no description yet (image preserved, but the .ai.md "
            f"placeholder carries no diagram content). To complete these: in Confluence, open each "
            f"diagram in the draw.io editor, File > Export > XML ('Compressed' unchecked), and save "
            f"as one of: {', '.join(pending)} — then re-run with --diagram-xml-dir pointing at the "
            f"folder containing those files."
        )

    return report
