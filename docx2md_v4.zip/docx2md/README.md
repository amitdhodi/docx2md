# docx2md — Lossless HLD/LLD DOCX → Markdown Converter (with token-optimized AI variant)

Converts HLD/LLD design docs from `.docx` to `.md` for use as AI-agent input
(e.g. AWS AI-DLC Construction phase, GitHub Copilot in Visual Studio), with a
built-in validation step so a lossy conversion never silently becomes the
agent's source of truth — **and** a second, token-optimized variant purpose-built
for feeding to a code-generation agent without wasting context on unusable
image links or markup overhead.

## Two output files per document

Every conversion produces **both**:

| File | Purpose |
|---|---|
| `HLD.md` | Full-fidelity, human-reviewable. Contains real image links + (if captioned) descriptive blockquotes under each diagram. This is the source of truth the validation report checks against the original `.docx`. |
| `HLD.ai.md` | Token-optimized, for feeding to Copilot/AI-DLC. No image links (a text-only agent can't render them anyway — they're pure token cost with zero payoff), merged table cells denormalized into compact plain pipe tables instead of HTML, diagrams represented as compact inline `[Diagram N: ...]` tags, all extra whitespace collapsed. |

Why two files instead of one: the "no data loss" guarantee and the
"minimum tokens for code-gen" goal are in tension if forced into a single
file (fully lossless visual fidelity costs tokens; token-optimized markup
discards visual fidelity that doesn't matter to a text-only reader anyway).
Generating both from the same parsed source, with a report cross-checking
that the AI variant still carries every heading/table/diagram, gets you both
properties without compromising either.

## Why this exists

Design docs feeding an AI coding agent are only as good as the fidelity of
the conversion, and only as usable as their token footprint allows. Generic
DOCX→Markdown tools tend to silently drop:
- merged table cells (Markdown tables have no colspan/rowspan concept)
- list numbering/nesting (many tools flatten to plain paragraphs)
- diagrams (become an unreadable image link with no semantic content for a
  text-only agent, or get dropped outright if they're vector/SmartArt shapes)

...and even when they don't drop content, they rarely think about **token
cost**: image links a text-only agent can't use, HTML tables where a plain
pipe table would do, stray whitespace, non-breaking-space filler cells.

This utility handles each of those explicitly, optimizes the AI-facing copy
for token cost, and **validates** both outputs so neither loss nor
over-optimization happens silently.

## Install

```bash
pip install -r requirements.txt
```

## Usage

```bash
python -m docx2md HLD.docx LLD.docx -o ./ai-design-package
```

This alone gets you the full pipeline: text, tables, and diagrams-as-images with
zero data loss. Diagrams won't have a text description yet — see the workflow
below for that, which is required if you want Copilot to actually understand
what's in them (it doesn't automatically resolve/render image links in a
markdown file it reads as context).

### Recommended: diagram descriptions via manually-exported draw.io XML (no model, no API, no data leaves your network)

This is the recommended path if running a local model (Ollama) isn't an option
due to resource constraints, and you don't have Confluence API token access.
draw.io's native format (mxGraph XML) is a literal graph — every shape is a
node with a label, every connector is an edge with `source`/`target`
references — so the relationships between components can be read directly
out of the file with plain XML parsing. No model involved anywhere, more
accurate than a vision model would be (it's reading the actual authored
data, not reconstructing structure from pixels), and nothing ever leaves
your machine.

**Two ways to run this — pick whichever fits:**

**Option A — one shot, if you already know your diagrams.** Export every
diagram's XML from Confluence up front (see Step 2 below), name each file
`image-001.xml`, `image-002.xml`, ... **in the order the diagrams appear
reading the document top-to-bottom** (numbering is based on reading order,
not file/relationship order, so this is reliable to predict without running
the tool first), then run once:
```bash
python -m docx2md HLD.docx LLD.docx -o ./ai-design-package --diagram-xml-dir ./diagram_sources
```
If a filename doesn't match, that diagram just gets the "no description yet"
placeholder — never an error — so there's no risk in guessing wrong; check
the validation report afterward and re-run if anything needs fixing.

**Option B — two passes, if you're not sure how many diagrams there are or
want the exact filenames confirmed before exporting anything:**

**Step 1 — run the conversion once to see what needs exporting:**
```bash
python -m docx2md HLD.docx LLD.docx -o ./ai-design-package
```
Check `ai-design-package/HLD.validation.md` — it lists exactly which diagrams
still need a description and what filename to save each one as, e.g.:
> 1 diagram(s) have no description yet ... save as one of: image-001.xml

**Step 2 — export each diagram's XML from Confluence:**
For each flagged diagram, open the page in Confluence → open the diagram in
the draw.io editor → **File → Export → XML** → make sure **"Compressed" is
UNCHECKED** (compressed exports are a base64/deflate blob the parser can't
read — it will tell you clearly if you hand it one of these). Save with the
exact filename the validation report told you (e.g. `image-001.xml`).

**Step 3 — put them all in one folder and re-run with `--diagram-xml-dir`:**
```bash
python -m docx2md HLD.docx LLD.docx -o ./ai-design-package --diagram-xml-dir ./diagram_sources
```
Matching is by filename: `diagram_sources/image-001.xml` maps to the diagram
extracted as `assets/image-001.png`. Any diagram with a matching file gets a
deterministic description like:
> Components: API Gateway, Payment Service, Stripe. Relationships: API Gateway -> Payment Service; Payment Service -> Stripe [calls].

...merged into both `HLD.md` (as a blockquote under the image) and
`HLD.ai.md` (as a compact `[Diagram N: ...]` tag with no image link). Check
`HLD.validation.md` again afterward — any XML file that failed to parse
(e.g. still compressed, or genuinely empty of shapes) is flagged there and
on the console, never silently skipped.

### Alternative: vision-model captioning (if you can use Ollama or a cloud API)

```bash
# With diagram captioning - REQUIRED for the .ai.md diagrams to carry
# actual content, since Copilot in Visual Studio does not automatically
# resolve/render image links found inside a markdown file it reads as
# context (it only processes images you explicitly attach to a prompt):
python -m docx2md HLD.docx LLD.docx -o ./ai-design-package --caption-images

# Treat any validation FAIL as a hard error (e.g. in CI):
python -m docx2md HLD.docx LLD.docx -o ./ai-design-package --fail-on-validation-error
```

Both `--diagram-xml-dir` and `--caption-images` can be combined: the
deterministic XML description takes priority for any diagram with a matching
file, and vision captioning only covers the remainder.

Output layout:

```
ai-design-package/
├── HLD.md                     <- full fidelity, human-reviewable
├── HLD.ai.md                  <- token-optimized, feed THIS to Copilot/AI-DLC
├── HLD.validation.md          <- read this before trusting either .md - also lists
│                                  which diagrams still need a draw.io XML export
├── LLD.md
├── LLD.ai.md
├── LLD.validation.md
├── .caption_cache.json        <- only created if --caption-images is used
└── assets/
    ├── image-001.png          <- natively extracted diagrams (Tier 1)
    └── full_document_page_renders/   <- only created if Tier-2 fallback triggered
        └── page-001.png
```

Separately, wherever you keep the manually-exported draw.io XML files:
```
diagram_sources/
├── image-001.xml               <- matched by filename to assets/image-001.png
└── image-002.xml
```

## Predictability: the caption cache

Every `--caption-images` run writes `.caption_cache.json` in the output
directory, keyed by a SHA-256 hash of each image's bytes. Re-running the
conversion (e.g. after a small text edit elsewhere in the doc) reuses the
exact same cached caption for any unchanged diagram instead of calling the
vision model again. This gives you two things:

- **Deterministic output** — the same `.docx` content always produces
  byte-identical `.md`/`.ai.md`, since unchanged diagrams never get reworded.
- **Lower cost** — you're not re-billing the vision model for diagrams that
  haven't changed since the last run.

Both captioners also call their model at `temperature=0` to minimize
non-determinism on the (rare) cache-miss path. Delete `.caption_cache.json`
if you deliberately want captions regenerated (e.g. after upgrading the
model).

## How fidelity is preserved (`.md`, the full variant)

| Source content | Handling |
|---|---|
| Headings | Style-based detection (`Heading 1`..`6`, `Title`) → `#`..`######` |
| Bold/italic | Preserved via run formatting → `**bold**` / `*italic*` |
| Bulleted/numbered lists | Read from `numbering.xml` (with a style-name fallback for docs that use named list styles without explicit `numPr`); nesting preserved via indent |
| Tables, no merges | Clean Markdown table |
| Tables, with merged cells | Rendered as inline HTML `<table>` with real `rowspan`/`colspan` — Markdown tables cannot represent merges, so flattening them would be silent data loss |
| Diagrams (raster) | Extracted directly from the docx package at original resolution into `assets/` |
| Diagrams (EMF/WMF vector) | Converted to PNG via LibreOffice headless |
| Diagrams (SmartArt / pure vector shapes with no raster fallback) | Tier-2 fallback: whole document rendered to page images in `assets/full_document_page_renders/`, and explicitly flagged in the validation report for manual review — never silently dropped |
| Diagram *semantics*, deterministic (recommended) | `--diagram-xml-dir` reads manually-exported draw.io XML files (matched by filename) and extracts components + relationships directly from the graph data — no model, no network call, most accurate option since it reads the real authored structure rather than reconstructing it from pixels |
| Diagram *semantics*, model-based (alternative) | `--caption-images` runs each extracted diagram through a vision model instead. Two backends: `--caption-backend ollama` (default) runs **fully locally** — no image data leaves your network. `--caption-backend anthropic` calls the Anthropic API over the network. |

## How tokens are minimized (`.ai.md`, the AI-facing variant)

| Optimization | Effect |
|---|---|
| No image links | A markdown image reference is dead weight to a text-only agent that doesn't resolve linked images (this is the case for Copilot in Visual Studio reading a `.md` as file context) — costs tokens, returns nothing. Dropped entirely in favor of the caption text. |
| Diagrams as compact tags | `[Diagram 1: <description>]` instead of `![diagram: image-001.png](assets/image-001.png)\n\n> **Diagram description:** ...` — same information, far fewer tokens. |
| Merged cells denormalized | Instead of an HTML `<table>` with `rowspan`/`colspan` attributes, the merged value is repeated into every column it spans in a plain pipe table — cheaper in tokens and equally informative to a model (a repeated value across columns *is* the semantic meaning of "this header applies to both"). |
| No `&nbsp;` filler | Empty table cells are just empty in the AI variant, not padded. |
| Whitespace minified | Trailing whitespace stripped per line; 3+ consecutive blank lines collapsed to exactly 1. |
| Deterministic captions | Cached by image hash + `temperature=0`, so re-running the pipeline doesn't cost extra tokens on unchanged diagrams and doesn't produce a different `.ai.md` for the same source. |

### Captioning backends

**Ollama (local, default — recommended for sensitive docs, nothing leaves your network)**
```bash
# One-time setup:
#   https://ollama.com/download
ollama pull qwen3-vl:8b      # or qwen3-vl:4b on lighter hardware
ollama serve                  # runs on localhost:11434, no external calls

pip install requests
python -m docx2md HLD.docx LLD.docx -o ./ai-design-package --caption-images
# equivalent to: --caption-images --caption-backend ollama --caption-model qwen3-vl:8b
```
Nothing is sent anywhere except `localhost` (or an internal Ollama host you point
`--ollama-host` at). Qwen3-VL is currently the strongest open-weight model for
document/diagram understanding; `llama3.2-vision` is a solid fallback if
qwen3-vl isn't available in your Ollama build.

**Anthropic API (cloud)**
```bash
pip install anthropic
export ANTHROPIC_API_KEY=your_key_here
python -m docx2md HLD.docx LLD.docx -o ./ai-design-package --caption-images --caption-backend anthropic
```

## Validation step

Every conversion produces a `<name>.validation.md` report with two layers:

1. **Source vs. full `.md`** — independently recomputes counts from the
   **source `.docx`** (headings, tables, unique table cells post-merge, word
   count, images) and compares them against the **generated `.md`**.
   Exact-match categories must match exactly; word count allows a small
   tolerance and excludes captioning-added text (which is legitimate
   enrichment, not part of the original content). Any mismatch fails the
   report.
2. **Full `.md` vs. AI variant** — checks that the token-optimized `.ai.md`
   still has the same heading count, same table count, and one diagram
   mention per extracted image — i.e. that optimizing for tokens didn't
   accidentally drop information.

The report also includes a rough token-count estimate for both files and the
percentage reduction, so you can see the savings on your actual documents.

## Known limitations (by design, always surfaced in the report, never silent)

- Tables nested inside other table cells are extracted (recursively), but
  deeply nested layout tables used purely for visual formatting are treated
  the same as content tables.
- SmartArt/pure-vector diagrams without a raster fallback require LibreOffice
  to be installed for the Tier-2 fallback; without it, the report explicitly
  says so and fails validation rather than pretending nothing was lost.
- `--caption-images` requires network access (Anthropic backend) or a running
  local Ollama instance; it's opt-in and never silently skipped without a
  note in the report — but without it, `.ai.md` diagrams are placeholder
  markers only ("not captioned"), not real descriptions.
- The token estimate is a ~4 chars/token heuristic, not the exact tokenizer
  Copilot's underlying model uses — treat it as directional, not exact.
