"""
Converts a single python-docx Paragraph into a Markdown line/block.

Handles:
  - Heading levels (Heading 1..6, Title) -> '#'..'######'
  - Bullet / numbered lists (via numbering.xml, with nesting by indent level)
  - Bold / italic run formatting
  - Inline images anchored inside a run (delegates the actual image bytes to
    images.py; this module just asks the image_map for the markdown snippet
    to splice in at the correct position in the sentence)
"""

import re
from docx.oxml.ns import qn

HEADING_RE = re.compile(r"^Heading (\d)$")

# python-docx's qn() helper doesn't have the "mc" (markup-compatibility) prefix
# registered, so these two are addressed by full Clark-notation tag directly.
_MC_NS = "http://schemas.openxmlformats.org/markup-compatibility/2006"
_MC_ALTERNATE_CONTENT = f"{{{_MC_NS}}}AlternateContent"
_MC_CHOICE = f"{{{_MC_NS}}}Choice"


def heading_level(paragraph):
    style_name = (paragraph.style.name or "").strip() if paragraph.style else ""
    if style_name == "Title":
        return 1
    m = HEADING_RE.match(style_name)
    if m:
        return min(int(m.group(1)), 6)
    return None


class NumberingResolver:
    """
    Resolves whether a paragraph's numPr (numbering properties) refers to a
    bulleted or an ordered/numbered list, and tracks per-list-id counters so
    numbered lists render as 1. 2. 3. instead of repeating '1.' (python-docx
    does not do this for you; Word computes it at render time from numbering.xml).
    """

    def __init__(self, document):
        self._document = document
        self._counters = {}  # (numId, ilvl) -> current count
        try:
            self._numbering_part = document.part.numbering_part
            self._numbering_elm = self._numbering_part.element
        except Exception:
            self._numbering_elm = None

    def _abstract_num_id(self, num_id):
        if self._numbering_elm is None:
            return None
        for num_el in self._numbering_elm.findall(qn("w:num")):
            if num_el.get(qn("w:numId")) == str(num_id):
                abstract = num_el.find(qn("w:abstractNumId"))
                if abstract is not None:
                    return abstract.get(qn("w:val"))
        return None

    def _fmt_for_level(self, abstract_num_id, ilvl):
        if self._numbering_elm is None or abstract_num_id is None:
            return None
        for abs_el in self._numbering_elm.findall(qn("w:abstractNum")):
            if abs_el.get(qn("w:abstractNumId")) == str(abstract_num_id):
                for lvl_el in abs_el.findall(qn("w:lvl")):
                    if lvl_el.get(qn("w:ilvl")) == str(ilvl):
                        fmt = lvl_el.find(qn("w:numFmt"))
                        if fmt is not None:
                            return fmt.get(qn("w:val"))
        return None

    def classify(self, paragraph):
        """
        Returns (is_list, ordered, level, marker) or (False, None, None, None).
        marker is the exact text to prefix the line with, e.g. '- ' or '3. '.
        """
        pPr = paragraph._p.pPr
        if pPr is None or pPr.numPr is None:
            # Fallback: some documents (and python-docx-authored ones) apply a
            # named list style (e.g. "List Bullet", "List Number") without
            # writing explicit numPr on the paragraph. Word still renders these
            # as lists via the style's own numbering link, so treat the style
            # name as a signal rather than silently dropping the list marker.
            style_name = (paragraph.style.name or "") if paragraph.style else ""
            if "List Bullet" in style_name:
                return True, False, 0, "- "
            if "List Number" in style_name:
                key = ("style:" + style_name, 0)
                self._counters[key] = self._counters.get(key, 0) + 1
                return True, True, 0, f"{self._counters[key]}. "
            return False, None, None, None
        numPr = pPr.numPr
        numId_el = numPr.find(qn("w:numId"))
        ilvl_el = numPr.find(qn("w:ilvl"))
        if numId_el is None:
            return False, None, None, None
        num_id = numId_el.get(qn("w:val"))
        ilvl = int(ilvl_el.get(qn("w:val"))) if ilvl_el is not None else 0

        abstract_id = self._abstract_num_id(num_id)
        fmt = self._fmt_for_level(abstract_id, ilvl)
        ordered = fmt not in (None, "bullet")

        key = (num_id, ilvl)
        if ordered:
            self._counters[key] = self._counters.get(key, 0) + 1
            # reset deeper levels when we hit this level again
            for k in list(self._counters):
                if k[0] == num_id and k[1] > ilvl:
                    del self._counters[k]
            marker = f"{self._counters[key]}. "
        else:
            marker = "- "

        return True, ordered, ilvl, marker


def _run_to_markdown(run, image_map, mode="full"):
    """Render a single run: bold/italic wrapping + inline image substitution."""
    blips = _run_image_blips(run)
    if blips:
        pieces = []
        for blip in blips:
            r_embed = blip.get(qn("r:embed")) or blip.get(qn("r:link"))
            if r_embed and r_embed in image_map:
                entry = image_map[r_embed]
                pieces.append(entry["markdown"] if mode == "full" else entry.get("ai_markdown", entry["markdown"]))
        if pieces:
            return "\n\n" + "\n\n".join(pieces) + "\n\n"

    text = run.text
    if not text:
        return ""
    if run.bold and run.italic:
        text = f"***{text}***"
    elif run.bold:
        text = f"**{text}**"
    elif run.italic:
        text = f"*{text}*"
    return text


def _run_image_blips(run):
    """
    Returns the a:blip elements that represent this run's ACTUAL rendered
    picture(s) - not every blip that happens to exist anywhere in the run's XML.

    Word frequently wraps a single picture in <mc:AlternateContent>, with a
    <mc:Choice> branch (what modern Word actually renders) and a <mc:Fallback>
    branch (a second, separate image relationship, only shown by very old Word
    versions that don't support the Choice's required extension). A naive
    './/a:blip' search finds BOTH - one physical picture in the document then
    surfaces as two separate image references in the output, sometimes with an
    odd internal extension on the Fallback part (a real Word packaging quirk).
    Only mc:Choice is used here; mc:Fallback content is intentionally ignored
    as a rendering duplicate, not a second real image.

    Runs with no AlternateContent wrapper (the common case) are unaffected -
    all blips found are used, since e.g. a grouped shape legitimately
    containing multiple distinct pictures should still yield multiple images.
    """
    alt_content = run._element.find(".//" + _MC_ALTERNATE_CONTENT)
    if alt_content is None:
        return run._element.findall(".//" + qn("a:blip"))

    choice = alt_content.find(_MC_CHOICE)
    if choice is not None:
        choice_blips = choice.findall(".//" + qn("a:blip"))
        if choice_blips:
            return choice_blips
    # No Choice branch or it had no image - fall back to whatever blips exist,
    # rather than silently returning nothing (never silently drop an image).
    return alt_content.findall(".//" + qn("a:blip"))


def paragraph_to_markdown(paragraph, numbering_resolver, image_map, mode="full"):
    """
    Returns a Markdown string for this paragraph (without trailing newline
    management - caller joins blocks with blank lines).
    mode="full" (human-reviewable, image links + caption blockquotes) or
    mode="ai" (token-optimized, compact inline diagram tags, no image links).
    """
    level = heading_level(paragraph)
    body = "".join(_run_to_markdown(r, image_map, mode) for r in paragraph.runs).strip()

    is_list, ordered, ilvl, marker = numbering_resolver.classify(paragraph)

    if level:
        return "#" * level + " " + body

    if is_list:
        indent = "  " * (ilvl or 0)
        return f"{indent}{marker}{body}"

    if not body:
        return ""  # empty paragraph -> blank line (handled by caller)

    return body
