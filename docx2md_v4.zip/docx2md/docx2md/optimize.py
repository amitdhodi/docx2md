"""
Token-cost hygiene for the AI-facing markdown variant. Nothing here removes
information — it only removes bytes that cost tokens without carrying meaning
(redundant blank lines, trailing whitespace, filler non-breaking spaces used
purely for empty-cell padding in the source DOCX).
"""

import re

MULTI_BLANK_RE = re.compile(r"\n{3,}")
TRAILING_WS_RE = re.compile(r"[ \t]+$", re.MULTILINE)


def minify_markdown(text: str) -> str:
    text = TRAILING_WS_RE.sub("", text)
    text = MULTI_BLANK_RE.sub("\n\n", text)  # collapse 3+ newlines -> exactly 1 blank line
    text = text.strip("\n") + "\n"
    return text


def estimate_tokens(text: str) -> int:
    """
    Real BPE token count via tiktoken's cl100k_base encoding (used by GPT-4-class
    models) when available - closer to what Copilot's underlying model actually
    sees than a length heuristic, though not an exact match for every model
    Copilot might route to.

    IMPORTANT: tiktoken downloads its encoding's merge table from a remote URL
    the first time it's used, and caches it locally after that. On a fully
    offline/air-gapped machine (the setup this utility otherwise supports end
    to end - no Ollama, no Confluence API, no cloud captioning), that first
    call will fail. This is caught broadly (not just ImportError) so a missing
    network never breaks the conversion - it just falls back to the heuristic.
    If you want the more accurate count while offline, run estimate_tokens once
    on a machine with internet access first so tiktoken's cache gets populated,
    then copy ~/.cache/tiktoken to the offline machine.
    """
    try:
        import tiktoken

        enc = tiktoken.get_encoding("cl100k_base")
        return len(enc.encode(text))
    except Exception:
        return max(1, len(text) // 4)
