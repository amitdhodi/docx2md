"""
docx2md - Lossless DOCX -> Markdown conversion utility for HLD/LLD design docs.

Pipeline:
    1. walker      - walks the document body in original order (paragraphs + tables interleaved)
    2. text         - converts paragraphs/runs to Markdown (headings, lists, bold/italic)
    3. tables       - converts tables to Markdown/HTML preserving merged cells
    4. images       - extracts raster images natively; rasterizes non-raster drawings
                       (SmartArt / OLE objects / vector shapes) via LibreOffice as a fallback
    5. captioning   - pluggable vision captioning for extracted diagrams (optional)
    6. converter    - orchestrates 1-5, writes out <name>.md + assets/
    7. validate     - compares source-doc counts vs generated markdown counts, produces a
                       validation report, and flags anything that could not be extracted natively
"""

__version__ = "0.1.0"
