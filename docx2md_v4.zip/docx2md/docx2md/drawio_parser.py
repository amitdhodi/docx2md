"""
Parses a manually-exported draw.io / diagrams.net XML file (mxGraph format,
File -> Export -> XML, "Compressed" UNCHECKED so it's plain readable XML) and
produces a deterministic text description of the diagram's structure.

No model of any kind is involved. draw.io's native format IS a graph data
structure - every shape is a <mxCell vertex="1"> with an id and a label, and
every connector is an <mxCell edge="1"> with source/target attributes
referencing those ids. Relationships are literal data, not something inferred
from pixels, so this is strictly more accurate than any vision model for
diagrams that are still available in their original draw.io form.
"""

import html
import re
from pathlib import Path
from xml.etree import ElementTree as ET

TAG_RE = re.compile(r"<[^>]+>")


def _clean_label(raw: str) -> str:
    """draw.io cell values are often HTML fragments, e.g. '<div>API Gateway</div>'."""
    if not raw:
        return ""
    text = TAG_RE.sub(" ", raw)
    text = html.unescape(text)
    return " ".join(text.split())


def parse_drawio_xml(xml_path: Path) -> str:
    """
    Returns a deterministic text description of the diagram's components and
    the relationships between them, e.g.:

        Components: API Gateway, Payment Service, Stripe.
        Relationships: API Gateway -> Payment Service; Payment Service -> Stripe [calls].

    Raises ValueError with a clear message if the file isn't a plain (uncompressed)
    mxGraph XML export - draw.io's "Compressed" export option produces a deflated,
    base64-encoded blob this parser intentionally does not attempt to decode,
    since a failed decode would be a silent-accuracy risk rather than a clean error.
    """
    text = Path(xml_path).read_text(encoding="utf-8", errors="replace")

    try:
        root = ET.fromstring(text)
    except ET.ParseError as exc:
        raise ValueError(f"{xml_path}: not valid XML ({exc})") from exc

    # Handle both a raw <mxGraphModel> root and an <mxfile><diagram> wrapper.
    graph_model = root if root.tag == "mxGraphModel" else root.find(".//mxGraphModel")
    if graph_model is None:
        # <mxfile><diagram>...</diagram></mxfile> with compressed (base64+deflate)
        # content has no <mxGraphModel> to find at all.
        diagram_el = root.find(".//diagram")
        if diagram_el is not None and (diagram_el.text or "").strip():
            raise ValueError(
                f"{xml_path}: this is a COMPRESSED draw.io export (base64/deflate-encoded). "
                f"Re-export with File -> Export -> XML and uncheck 'Compressed' so the "
                f"relationships can be read as plain text."
            )
        raise ValueError(f"{xml_path}: no <mxGraphModel> found - not a recognized draw.io XML export.")

    labels = {}
    edges = []  # (source_label, target_label, edge_label)

    for cell in graph_model.iter("mxCell"):
        cell_id = cell.get("id")
        if cell.get("vertex") == "1":
            labels[cell_id] = _clean_label(cell.get("value", ""))

    for cell in graph_model.iter("mxCell"):
        if cell.get("edge") == "1":
            src, tgt = cell.get("source"), cell.get("target")
            if src and tgt:
                edges.append((labels.get(src, f"[unlabeled:{src}]"), labels.get(tgt, f"[unlabeled:{tgt}]"), _clean_label(cell.get("value", ""))))

    component_names = [v for v in labels.values() if v]
    parts = []
    if component_names:
        parts.append("Components: " + ", ".join(component_names) + ".")
    if edges:
        rel_strs = []
        for src, tgt, lbl in edges:
            rel_strs.append(f"{src} -> {tgt}" + (f" [{lbl}]" if lbl else ""))
        parts.append("Relationships: " + "; ".join(rel_strs) + ".")

    if not parts:
        raise ValueError(f"{xml_path}: parsed successfully but found no labeled shapes or connectors.")

    return " ".join(parts)


def apply_drawio_descriptions(image_map: dict, xml_dir) -> dict:
    """
    For each extracted diagram, looks for a matching manually-exported draw.io
    XML file in xml_dir (matched by filename stem, e.g. assets/image-001.png ->
    xml_dir/image-001.xml) and, if found, uses the deterministic parsed
    description IN PLACE OF vision captioning for that image - it's more
    accurate (literal graph data, not a reconstruction from pixels) and needs
    no model at all. Images without a matching XML file are left untouched
    (still get vision captioning if --caption-images is also set, or the
    "not captioned" placeholder otherwise).

    Returns a dict of {image_filename: error_message} for any XML files that
    were found but failed to parse - callers should surface these, never
    silently ignore them.
    """
    xml_dir = Path(xml_dir)
    errors = {}
    diagram_number = 0

    for entry in image_map.values():
        if entry["kind"] != "raster":
            continue
        diagram_number += 1
        stem = Path(entry["path"]).stem
        xml_path = xml_dir / f"{stem}.xml"
        if not xml_path.exists():
            continue

        try:
            description = parse_drawio_xml(xml_path)
        except ValueError as exc:
            errors[str(xml_path)] = str(exc)
            entry["caption_error"] = str(exc)
            continue

        entry["markdown"] = entry["markdown"] + f"\n\n> **Diagram description (from draw.io source, deterministic):** {description}"
        entry["ai_markdown"] = f"[Diagram {diagram_number}: {description}]"

    return errors
