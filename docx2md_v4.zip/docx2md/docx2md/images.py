"""
Image handling has two tiers:

Tier 1 (primary, high fidelity): every relationship of type IMAGE embedded in the
docx is extracted directly from the zip package. This covers the overwhelming
majority of real-world cases - screenshots/diagrams pasted from draw.io, Lucidchart,
Confluence macros, etc. come through as PNG/JPEG. Legacy EMF/WMF (Windows vector
metafile) images are converted to PNG via LibreOffice so they're actually viewable.

Tier 2 (fallback, flagged for manual review): a <w:drawing> element with NO <a:blip>
anywhere inside it is a pure vector shape/SmartArt with no embedded raster fallback -
python-docx/lxml cannot rasterize DrawingML natively. Rather than silently dropping
these, the whole document is rendered to PDF via LibreOffice headless and every page
is saved as a reference PNG, and the gap is explicitly called out in the validation
report so a human can verify nothing meaningful was lost.
"""

import subprocess
import shutil
from pathlib import Path

from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT

from .walker import iter_all_paragraphs
from .text import _run_image_blips

RASTER_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff"}
VECTOR_EXTS = {".emf", ".wmf"}


def _collect_referenced_rids(document):
    """
    Returns (ordered_unique_rids, total_occurrences).

    ordered_unique_rids is in FIRST-ENCOUNTERED BODY ORDER - i.e. the order a
    person reads the document top-to-bottom - not raw relationship-file order.
    This matters: Word's document.xml.rels can list relationships in whatever
    order they were added during editing history, which is NOT guaranteed to
    match reading order after revisions/reordering. If image numbering were
    based on relationship-file order, pre-naming exported draw.io XML files
    ("the 3rd diagram I see in the doc") could silently mismatch the filename
    the utility actually expects - this makes "image-001" reliably mean
    "the first diagram encountered reading the document top-to-bottom",
    enabling a one-shot run (export all diagrams' XML up front, no need to
    run once just to discover filenames).

    total_occurrences is the TOTAL count of inline occurrences across the
    whole body - i.e. if the same image is legitimately referenced twice (a
    repeated icon/logo/diagram), that counts as 2 occurrences even though
    it's 1 unique relationship ID. Validation needs the occurrence count, not
    the unique count, to correctly compare against how many "![...]"
    references actually appear in the generated markdown.
    """
    seen = set()
    ordered_unique_rids = []
    total_occurrences = 0
    for paragraph in iter_all_paragraphs(document):
        for run in paragraph.runs:
            for blip in _run_image_blips(run):
                r_embed = blip.get(qn("r:embed")) or blip.get(qn("r:link"))
                if r_embed:
                    total_occurrences += 1
                    if r_embed not in seen:
                        seen.add(r_embed)
                        ordered_unique_rids.append(r_embed)
    return ordered_unique_rids, total_occurrences


def _soffice_available():
    return shutil.which("soffice") is not None


def _convert_with_soffice(src_path: Path, out_dir: Path, out_ext: str) -> Path | None:
    if not _soffice_available():
        return None
    try:
        subprocess.run(
            ["soffice", "--headless", "--convert-to", out_ext, "--outdir", str(out_dir), str(src_path)],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=120,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return None
    candidate = out_dir / (src_path.stem + f".{out_ext}")
    return candidate if candidate.exists() else None


def extract_raster_images(document, assets_dir: Path):
    """
    Extracts every embedded IMAGE relationship that is actually referenced in
    the rendered document body (see _collect_referenced_rids) to assets_dir.
    Returns (image_map, total_inline_occurrences) - the latter is the count
    validation needs to correctly check "every inline picture reference made
    it into the markdown," accounting for images used more than once.
    """
    assets_dir.mkdir(parents=True, exist_ok=True)
    image_map = {}
    counter = 0
    ordered_rids, total_occurrences = _collect_referenced_rids(document)

    for rel_id in ordered_rids:  # body-reading order, not relationship-file order
        rel = document.part.rels.get(rel_id)
        if rel is None or rel.reltype != RT.IMAGE or rel.is_external:
            continue
        counter += 1
        part = rel.target_part
        ext = Path(part.partname).suffix.lower() or ".png"
        fname = f"image-{counter:03d}{ext}"
        out_path = assets_dir / fname

        with open(out_path, "wb") as f:
            f.write(part.blob)

        final_path = out_path
        if ext in VECTOR_EXTS:
            converted = _convert_with_soffice(out_path, assets_dir, "png")
            if converted:
                final_path = converted
            # else: keep the .emf/.wmf as-is; flagged as low-fidelity in validation

        rel_display = final_path.name
        kind = "raster" if final_path.suffix.lower() in RASTER_EXTS else "vector-unconverted"
        expected_xml_name = f"{final_path.stem}.xml"
        image_map[rel_id] = {
            "path": final_path,
            "markdown": f"![diagram: {fname}](assets/{rel_display})",
            # Default AI-variant text until a description is supplied. Points
            # directly at the manual draw.io XML export workflow (no model
            # required) rather than assuming a vision-captioning step will run.
            "ai_markdown": (
                f"[Diagram: {fname} — no description yet. Export as '{expected_xml_name}' via "
                f"draw.io File>Export>XML (uncheck Compressed) and pass --diagram-xml-dir.]"
            ),
            "expected_xml_name": expected_xml_name,
            "kind": kind,
        }

    return image_map, total_occurrences


def count_unresolved_vector_drawings(document):
    """
    Counts <w:drawing> elements that contain no <a:blip> anywhere inside them -
    i.e. pure DrawingML/SmartArt shapes with no raster fallback we can extract.
    """
    body = document.element.body
    count = 0
    for drawing in body.iter(qn("w:drawing")):
        if drawing.find(".//" + qn("a:blip")) is None:
            count += 1
    return count


def render_full_document_fallback(docx_path: Path, assets_dir: Path):
    """
    Tier 2 fallback: renders every page of the document to PNG via LibreOffice
    (docx -> pdf -> per-page png) so nothing is silently lost even when a vector
    drawing can't be natively extracted. Returns list of generated page image paths,
    or [] if LibreOffice / PyMuPDF is unavailable.
    """
    if not _soffice_available():
        return []

    fallback_dir = assets_dir / "full_document_page_renders"
    fallback_dir.mkdir(parents=True, exist_ok=True)

    pdf_path = _convert_with_soffice(docx_path, fallback_dir, "pdf")
    if not pdf_path:
        return []

    try:
        import fitz  # PyMuPDF
    except ImportError:
        return [pdf_path]  # at least the PDF is there for manual review

    pages = []
    doc = fitz.open(pdf_path)
    for i, page in enumerate(doc, start=1):
        pix = page.get_pixmap(dpi=150)
        out_path = fallback_dir / f"page-{i:03d}.png"
        pix.save(out_path)
        pages.append(out_path)
    doc.close()
    return pages
