"""
Optional step: describe each extracted diagram in text so a text-only AI agent
(one that doesn't see the referenced image) still gets the diagram's semantic
content. This is intentionally pluggable - wire up whatever vision model your
org standardizes on (Bedrock, Anthropic API, Azure OpenAI, etc).

Left as an explicit opt-in (--caption-images) rather than default-on, since it
requires network/API credentials this utility shouldn't assume are present.
"""

import base64
from abc import ABC, abstractmethod
from pathlib import Path


class Captioner(ABC):
    @abstractmethod
    def caption(self, image_path: Path) -> str:
        """Return a text description of the diagram at image_path."""
        raise NotImplementedError


class NullCaptioner(Captioner):
    """Default no-op: leaves images as image-only references. Use when no
    vision API is configured; the validation report will note captioning was skipped."""

    def caption(self, image_path: Path) -> str:
        return ""


class AnthropicVisionCaptioner(Captioner):
    """
    Example implementation using the Anthropic API. Requires:
        pip install anthropic
        export ANTHROPIC_API_KEY=...

    NOTE: this sends diagram images to Anthropic's API over the network.
    For sensitive/internal design docs, use OllamaVisionCaptioner instead -
    it keeps every byte on your own network.
    """

    PROMPT = (
        "This image is a diagram from a software High-Level or Low-Level Design "
        "document. Describe it precisely and completely for an engineer who cannot "
        "see the image: components/boxes present, the relationships/arrows between "
        "them (direction and label if any), any numbered sequence of calls, and any "
        "text labels. Be literal and complete, not interpretive. Output plain text, "
        "no markdown headers."
    )

    def __init__(self, model: str = "claude-sonnet-5"):
        import anthropic  # imported lazily so it's not a hard dependency

        self._client = anthropic.Anthropic()
        self._model = model

    def caption(self, image_path: Path) -> str:
        ext = image_path.suffix.lower().lstrip(".")
        media_type = f"image/{'jpeg' if ext == 'jpg' else ext}"
        data = base64.standard_b64encode(image_path.read_bytes()).decode("utf-8")

        response = self._client.messages.create(
            model=self._model,
            max_tokens=600,
            temperature=0,  # deterministic - same image should yield the same caption
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "image", "source": {"type": "base64", "media_type": media_type, "data": data}},
                        {"type": "text", "text": self.PROMPT},
                    ],
                }
            ],
        )
        return "".join(block.text for block in response.content if block.type == "text").strip()


class OllamaVisionCaptioner(Captioner):
    """
    Fully local captioning via Ollama - no data leaves your network. This is the
    right choice for sensitive/internal HLD/LLD diagrams: the image bytes go to
    localhost (or an internal Ollama host you control) and nowhere else.

    Requires:
        Install Ollama: https://ollama.com/download
        ollama pull qwen3-vl:8b      # or qwen3-vl:4b on lighter hardware
        ollama serve                  # default: http://localhost:11434, no egress

    Recommended model: qwen3-vl (8b or 4b) - currently the strongest open-weight
    model for document/diagram OCR-style understanding, Apache 2.0 licensed.
    Llama 3.2 Vision (e.g. "llama3.2-vision") is a solid fallback if qwen3-vl
    isn't available in your Ollama build.
    """

    PROMPT = (
        "This image is a diagram from a software High-Level or Low-Level Design "
        "document. Describe it precisely and completely for an engineer who cannot "
        "see the image: components/boxes present, the relationships/arrows between "
        "them (direction and label if any), any numbered sequence of calls, and any "
        "text labels. Be literal and complete, not interpretive. Output plain text, "
        "no markdown headers."
    )

    def __init__(self, model: str = "qwen3-vl:8b", host: str = "http://localhost:11434", timeout: int = 120):
        self._model = model
        self._host = host.rstrip("/")
        self._timeout = timeout

    def caption(self, image_path: Path) -> str:
        import requests  # only needed if this captioner is actually used

        data = base64.standard_b64encode(image_path.read_bytes()).decode("utf-8")
        response = requests.post(
            f"{self._host}/api/generate",
            json={
                "model": self._model,
                "prompt": self.PROMPT,
                "images": [data],
                "stream": False,
                "options": {"temperature": 0},  # deterministic - same image -> same caption
            },
            timeout=self._timeout,
        )
        response.raise_for_status()
        return response.json().get("response", "").strip()


def caption_all(image_map: dict, captioner: Captioner, cache=None) -> dict:
    """
    Mutates image_map in place:
      - entry["markdown"]    gets a '> **Diagram description:** ...' blockquote
                              appended (human-reviewable, full-fidelity variant)
      - entry["ai_markdown"] gets a compact '[Diagram N: <description>]' tag with
                              NO image link at all (token-optimized variant - a
                              text-only agent can't render the image anyway, so
                              the link is pure token cost with zero payoff there)

    If `cache` (a CaptionCache) is provided, captions are looked up by image
    content hash first - this makes output deterministic across runs (unchanged
    diagrams always get the exact same caption) and avoids re-billing the vision
    model for images that haven't changed since the last conversion.
    """
    diagram_number = 0
    for entry in image_map.values():
        if entry["kind"] != "raster":
            # Vector/EMF assets not captioned - flagged separately in validation.
            # Still give the AI variant an explicit marker so its presence isn't
            # silently dropped from that file either.
            entry["ai_markdown"] = f"[Diagram: uncaptioned {entry['kind']} asset — see full .md / assets/]"
            continue

        diagram_number += 1
        image_bytes = Path(entry["path"]).read_bytes()

        description = cache.get(image_bytes) if cache else None
        cache_hit = description is not None
        if not cache_hit:
            try:
                description = captioner.caption(entry["path"])
            except Exception as exc:  # never let a captioning failure break the conversion
                description = ""
                entry["caption_error"] = str(exc)
            if cache and description:
                cache.set(image_bytes, description)

        if description:
            entry["markdown"] = entry["markdown"] + f"\n\n> **Diagram description:** {description}"
            entry["ai_markdown"] = f"[Diagram {diagram_number}: {description}]"
        else:
            entry["ai_markdown"] = f"[Diagram {diagram_number}: captioning failed — see full .md / assets/]"

    return image_map
