import re
from dataclasses import dataclass, field
from pathlib import Path

from docx.table import Table
from docx.text.paragraph import Paragraph

from .walker import walk_document
from .text import NumberingResolver, paragraph_to_markdown
from .tables import table_to_markdown
from .images import extract_raster_images, count_unresolved_vector_drawings, render_full_document_fallback
from .captioning import Captioner, NullCaptioner, caption_all
from .drawio_parser import apply_drawio_descriptions
from .cache import CaptionCache
from .optimize import minify_markdown, estimate_tokens

LIST_ITEM_RE = re.compile(r"^\d+\.\s")


@dataclass
class ConversionResult:
    docx_path: Path
    md_path: Path            # full, human-reviewable variant (source of truth for no-data-loss validation)
    ai_md_path: Path         # token-optimized variant for feeding to Copilot/AI-DLC
    output_dir: Path
    document: object
    blocks: list
    image_map: dict
    unresolved_vector_drawings: int
    fallback_pages: list = field(default_factory=list)
    full_tokens_est: int = 0
    ai_tokens_est: int = 0
    drawio_xml_errors: dict = field(default_factory=dict)
    expected_inline_image_refs: int = 0


def _join_blocks(lines):
    """Join rendered block strings with blank-line separation, except adjacent
    list items which stay on consecutive lines (so lists don't render as a
    sequence of separate loose paragraphs)."""
    out = []
    prev_is_list = False
    for line in lines:
        if line == "":
            continue
        stripped = line.lstrip(" ")
        is_list = stripped.startswith("- ") or bool(LIST_ITEM_RE.match(stripped))
        if out:
            out.append("\n" if (is_list and prev_is_list) else "\n\n")
        out.append(line)
        prev_is_list = is_list
    return "".join(out)


def _render(blocks, numbering_resolver, image_map, mode):
    md_blocks = []
    for block in blocks:
        if isinstance(block, Paragraph):
            md_blocks.append(paragraph_to_markdown(block, numbering_resolver, image_map, mode))
        elif isinstance(block, Table):
            md_blocks.append(table_to_markdown(block, numbering_resolver, image_map, paragraph_to_markdown, mode))
    return _join_blocks(md_blocks) + "\n"


def convert(
    docx_path,
    output_dir,
    caption_images: bool = False,
    captioner: Captioner | None = None,
    use_caption_cache: bool = True,
    diagram_xml_dir=None,
) -> ConversionResult:
    docx_path = Path(docx_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    assets_dir = output_dir / "assets"

    document, blocks = walk_document(docx_path)

    # --- Images (Tier 1: native raster extraction) ---
    image_map, expected_inline_image_refs = extract_raster_images(document, assets_dir)

    # --- Images (Tier 2: fallback for undetectable vector/SmartArt drawings) ---
    unresolved_vector_count = count_unresolved_vector_drawings(document)
    fallback_pages = []
    if unresolved_vector_count > 0:
        fallback_pages = render_full_document_fallback(docx_path, assets_dir)

    # --- Optional diagram captioning (feeds BOTH the full-variant blockquote
    #     and the compact AI-variant tag) ---
    if caption_images:
        cache = CaptionCache(output_dir / ".caption_cache.json") if use_caption_cache else None
        caption_all(image_map, captioner or NullCaptioner(), cache=cache)
        if cache:
            cache.save()

    # --- Deterministic diagram descriptions from manually-exported draw.io XML.
    #     Runs AFTER vision captioning so it can override with the more accurate,
    #     model-free description wherever a matching XML file is available. ---
    drawio_xml_errors = {}
    if diagram_xml_dir:
        drawio_xml_errors = apply_drawio_descriptions(image_map, diagram_xml_dir)

    # --- Text/table conversion in original document order, once per variant.
    # A fresh NumberingResolver per pass is required: it keeps running counters
    # for numbered lists, so reusing one instance across both renders would let
    # the AI-variant pass continue counting from wherever the full-variant pass
    # left off (e.g. list starting at "5." instead of "1.").
    full_text = _render(blocks, NumberingResolver(document), image_map, mode="full")
    ai_text_raw = _render(blocks, NumberingResolver(document), image_map, mode="ai")
    ai_text = minify_markdown(ai_text_raw)

    md_path = output_dir / (docx_path.stem + ".md")
    md_path.write_text(full_text, encoding="utf-8")

    ai_md_path = output_dir / (docx_path.stem + ".ai.md")
    ai_md_path.write_text(ai_text, encoding="utf-8")

    return ConversionResult(
        docx_path=docx_path,
        md_path=md_path,
        ai_md_path=ai_md_path,
        output_dir=output_dir,
        document=document,
        blocks=blocks,
        image_map=image_map,
        unresolved_vector_drawings=unresolved_vector_count,
        fallback_pages=fallback_pages,
        full_tokens_est=estimate_tokens(full_text),
        ai_tokens_est=estimate_tokens(ai_text),
        drawio_xml_errors=drawio_xml_errors,
        expected_inline_image_refs=expected_inline_image_refs,
    )
