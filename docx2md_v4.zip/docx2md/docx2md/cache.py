"""
Two problems this solves:

1. PREDICTABILITY: vision models are not guaranteed to return byte-identical
   text for the same image on every call (even at temperature=0, provider-side
   changes can shift wording slightly). If you re-run the conversion tomorrow
   because LLD.docx changed, every UNCHANGED diagram would still risk getting a
   reworded caption, making the .md diff noisy and the pipeline's output
   non-reproducible.
2. COST/TOKENS: re-captioning identical diagrams on every run burns API calls
   for zero new information.

Fix: cache captions keyed by a SHA-256 hash of the image bytes, persisted to
disk. Same image bytes -> same cached caption, forever, until the image itself
changes (new hash) or the cache is deleted.
"""

import hashlib
import json
from pathlib import Path


class CaptionCache:
    def __init__(self, cache_path: Path):
        self._path = Path(cache_path)
        self._data = {}
        if self._path.exists():
            try:
                self._data = json.loads(self._path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                self._data = {}

    @staticmethod
    def hash_bytes(data: bytes) -> str:
        return hashlib.sha256(data).hexdigest()

    def get(self, image_bytes: bytes):
        return self._data.get(self.hash_bytes(image_bytes))

    def set(self, image_bytes: bytes, caption: str):
        self._data[self.hash_bytes(image_bytes)] = caption

    def save(self):
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._path.write_text(json.dumps(self._data, indent=2, sort_keys=True), encoding="utf-8")
