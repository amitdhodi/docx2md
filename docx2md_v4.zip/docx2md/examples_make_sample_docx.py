from docx import Document
from docx.shared import Inches
from PIL import Image, ImageDraw
import io

doc = Document()

doc.add_heading("Payment Service - High Level Design", level=1)
p = doc.add_paragraph()
p.add_run("This document describes the ").bold = False
p.add_run("Payment Service").bold = True
p.add_run(", which handles ")
p.add_run("authorization, capture, and refunds").italic = True
p.add_run(" for the checkout platform.")

doc.add_heading("1. Overview", level=2)
doc.add_paragraph("The service exposes a REST API and integrates with two downstream providers.")

doc.add_heading("2. Downstream Integrations", level=2)
doc.add_paragraph("Key integration points:", style=None)
doc.add_paragraph("Stripe for card payments", style="List Bullet")
doc.add_paragraph("PayPal for wallet payments", style="List Bullet")
doc.add_paragraph("Internal Ledger service for reconciliation", style="List Bullet")

doc.add_heading("3. Processing Steps", level=2)
doc.add_paragraph("Validate request payload", style="List Number")
doc.add_paragraph("Call downstream provider", style="List Number")
doc.add_paragraph("Persist transaction record", style="List Number")
doc.add_paragraph("Emit audit event", style="List Number")

doc.add_heading("4. API Field Reference", level=2)
table = doc.add_table(rows=4, cols=3)
table.style = "Table Grid"
hdr = table.rows[0].cells
hdr[0].text = "Field"
hdr[1].text = "Type"
hdr[2].text = "Notes"
table.rows[1].cells[0].text = "amount"
table.rows[1].cells[1].text = "integer"
table.rows[1].cells[2].text = "minor units (cents)"
table.rows[2].cells[0].text = "currency"
table.rows[2].cells[1].text = "string"
table.rows[2].cells[2].text = "ISO 4217"
table.rows[3].cells[0].text = "idempotency_key"
table.rows[3].cells[1].text = "string"
table.rows[3].cells[2].text = "required, unique per request"

# Merge header cells 1&2 to create a genuine merged-cell case
merged_table = doc.add_table(rows=3, cols=3)
merged_table.style = "Table Grid"
a = merged_table.rows[0].cells[0]
a.text = "Environment"
b = merged_table.rows[0].cells[1].merge(merged_table.rows[0].cells[2])
b.text = "Endpoints"
merged_table.rows[1].cells[0].text = "staging"
merged_table.rows[1].cells[1].text = "https://staging.api.example.com"
merged_table.rows[1].cells[2].text = "internal only"
merged_table.rows[2].cells[0].text = "prod"
merged_table.rows[2].cells[1].text = "https://api.example.com"
merged_table.rows[2].cells[2].text = "public"

doc.add_heading("5. Architecture Diagram", level=2)
doc.add_paragraph("The diagram below shows the request flow between components.")

# Create a simple placeholder diagram image in-memory and embed it
img = Image.new("RGB", (500, 260), "white")
d = ImageDraw.Draw(img)
d.rectangle([20, 20, 180, 90], outline="black", width=2)
d.text((35, 50), "API Gateway", fill="black")
d.rectangle([220, 20, 380, 90], outline="black", width=2)
d.text((235, 50), "Payment Svc", fill="black")
d.rectangle([220, 150, 380, 220], outline="black", width=2)
d.text((250, 180), "Stripe", fill="black")
d.line([180, 55, 220, 55], fill="black", width=2)
d.line([300, 90, 300, 150], fill="black", width=2)
buf = io.BytesIO()
img.save(buf, format="PNG")
buf.seek(0)
with open("_tmp_diagram.png", "wb") as f:
    f.write(buf.getvalue())

doc.add_picture("_tmp_diagram.png", width=Inches(4))

doc.save("sample_HLD.docx")
print("Sample docx created.")
