"""
Token-cost hygiene for the AI-facing markdown variant. Nothing here removes
information — it only removes bytes that cost tokens without carrying meaning
(redundant blank lines, trailing whitespace, filler non-breaking spaces used
purely for empty-cell padding in the source DOCX).
"""

import re

MULTI_BLANK_RE = re.compile(r"\n{3,}")
TRAILING_WS_RE = re.compile(r"[ \t]+$", re.MULTILINE)


def minify_markdown(text: str) -> str:
    text = TRAILING_WS_RE.sub("", text)
    text = MULTI_BLANK_RE.sub("\n\n", text)  # collapse 3+ newlines -> exactly 1 blank line
    text = text.strip("\n") + "\n"
    return text


def estimate_tokens(text: str) -> int:
    """
    Rough heuristic (~4 chars/token for English prose, roughly holds for
    Markdown too). Good enough for reporting relative savings between the
    full and AI-optimized variants — not a substitute for a real tokenizer.
    """
    return max(1, len(text) // 4)
