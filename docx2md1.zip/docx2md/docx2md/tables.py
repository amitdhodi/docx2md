"""
Markdown tables cannot represent merged cells (no colspan/rowspan concept).
LLD tables (API/schema/config tables) frequently use merged header cells, so
silently flattening them would be a real data-loss case. Strategy:

  - Build the cell grid (python-docx's row.cells already repeats the same
    underlying <w:tc> for merged spans, so identity comparison reveals merges).
  - If NO merges are present anywhere in the table -> emit a clean Markdown table.
  - If ANY merge is present -> emit an HTML <table> with proper rowspan/colspan.
    GitHub-Flavored-Markdown renderers (and any LLM reading the .md as text)
    handle inline HTML tables fine, so this keeps the file valid Markdown while
    losing zero structural information.
"""

from docx.oxml.ns import qn


def _cell_paragraphs_to_text(cell, numbering_resolver, image_map, para_to_md, mode="full"):
    lines = []
    for p in cell.paragraphs:
        md = para_to_md(p, numbering_resolver, image_map, mode)
        if md:
            lines.append(md)
    return "<br>".join(lines) if lines else ""


def _build_grid(table):
    """Returns grid[row][col] = tc_element, using row.cells' natural merge repetition."""
    grid = []
    for row in table.rows:
        grid.append([c._tc for c in row.cells])
    return grid


def _has_merges(grid):
    if not grid:
        return False
    n_cols = len(grid[0])
    for row in grid:
        if len(set(id(tc) for tc in row)) != n_cols:
            return True
    for col in range(n_cols):
        col_tcs = [grid[r][col] for r in range(len(grid))]
        if len(set(id(tc) for tc in col_tcs)) != len(col_tcs):
            return True
    return False


def _spans(grid):
    """
    For each unique tc (by id), compute (row_start, col_start, rowspan, colspan)
    for its top-left occurrence, and the set of (row, col) cells it covers so
    we know which grid positions to skip when emitting.
    """
    n_rows = len(grid)
    n_cols = len(grid[0]) if n_rows else 0
    seen = set()
    spans = {}  # (row, col) -> (rowspan, colspan, tc)
    skip = set()

    for r in range(n_rows):
        for c in range(n_cols):
            tc = grid[r][c]
            key = id(tc)
            if key in seen:
                skip.add((r, c))
                continue
            seen.add(key)
            colspan = 1
            while c + colspan < n_cols and id(grid[r][c + colspan]) == key:
                colspan += 1
            rowspan = 1
            while r + rowspan < n_rows and id(grid[r + rowspan][c]) == key:
                rowspan += 1
            spans[(r, c)] = (rowspan, colspan, tc)

    return spans, skip


def table_to_markdown(table, numbering_resolver, image_map, para_to_md, mode="full"):
    """
    mode="full": merges rendered as HTML <table> with real rowspan/colspan
                  (visually faithful, used for the human-reviewable .md).
    mode="ai":   ALWAYS a plain pipe table, denormalized - a merged cell's text
                  is repeated into every column it spans. This costs roughly
                  half the tokens of an HTML table and loses no information a
                  code-generation agent needs: "this header applies to both
                  columns" is exactly what a repeated value conveys.
    """
    grid = _build_grid(table)
    if not grid or not grid[0]:
        return ""

    if mode == "ai":
        return _denormalized_markdown_table(table, grid, numbering_resolver, image_map, para_to_md)

    if not _has_merges(grid):
        return _simple_markdown_table(table, numbering_resolver, image_map, para_to_md)

    return _html_table(table, grid, numbering_resolver, image_map, para_to_md)


def _denormalized_markdown_table(table, grid, numbering_resolver, image_map, para_to_md):
    tc_to_cell = {}
    for row in table.rows:
        for cell in row.cells:
            tc_to_cell[id(cell._tc)] = cell

    rows_text = []
    for row_tcs in grid:
        cells_text = []
        for tc in row_tcs:
            cell = tc_to_cell.get(id(tc))
            if cell is not None:
                text = _cell_paragraphs_to_text(
                    cell, numbering_resolver, image_map, para_to_md, mode="ai"
                ).replace("\n", " ").strip()
            else:
                text = ""
            cells_text.append(text)  # empty allowed - no "&nbsp;" filler in the AI variant
        rows_text.append(cells_text)

    if not rows_text:
        return ""
    header = rows_text[0]
    lines = ["| " + " | ".join(header) + " |", "| " + " | ".join(["---"] * len(header)) + " |"]
    for r in rows_text[1:]:
        lines.append("| " + " | ".join(r) + " |")
    return "\n".join(lines)


def _simple_markdown_table(table, numbering_resolver, image_map, para_to_md):
    rows_text = []
    for row in table.rows:
        cells_text = [
            _cell_paragraphs_to_text(cell, numbering_resolver, image_map, para_to_md).replace("\n", " ").strip()
            or "&nbsp;"
            for cell in row.cells
        ]
        rows_text.append(cells_text)

    if not rows_text:
        return ""

    header = rows_text[0]
    lines = ["| " + " | ".join(header) + " |", "| " + " | ".join(["---"] * len(header)) + " |"]
    for r in rows_text[1:]:
        lines.append("| " + " | ".join(r) + " |")
    return "\n".join(lines)


def _html_table(table, grid, numbering_resolver, image_map, para_to_md):
    spans, skip = _spans(grid)
    n_rows = len(grid)
    n_cols = len(grid[0])

    # Map tc element -> the python-docx _Cell object, so we can pull paragraph text.
    tc_to_cell = {}
    for row in table.rows:
        for cell in row.cells:
            tc_to_cell[id(cell._tc)] = cell

    html = ['<table>']
    for r in range(n_rows):
        html.append("  <tr>")
        for c in range(n_cols):
            if (r, c) in skip:
                continue
            if (r, c) not in spans:
                continue
            rowspan, colspan, tc = spans[(r, c)]
            cell = tc_to_cell.get(id(tc))
            text = (
                _cell_paragraphs_to_text(cell, numbering_resolver, image_map, para_to_md)
                if cell is not None
                else ""
            )
            attrs = ""
            if rowspan > 1:
                attrs += f' rowspan="{rowspan}"'
            if colspan > 1:
                attrs += f' colspan="{colspan}"'
            tag = "th" if r == 0 else "td"
            html.append(f"    <{tag}{attrs}>{text}</{tag}>")
        html.append("  </tr>")
    html.append("</table>")
    return "\n".join(html)
